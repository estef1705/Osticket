<?php return array(
 'id' => 'clonemeagain:archiver', # notrans
 'version' => '0.1',
 'name' => 'Archiver',
 'author' => 'clonemeagain@gmail.com',
 'description' => 'Archives old tickets & deletes them..',
 'url' => 'https://github.com/clonemeagain/osticket-plugin-archiver',
 'plugin' => 'class.ArchiverPlugin.php:ArchiverPlugin'
);
