<?php return array(
 'id' => 'clonemeagain:mentioner', # notrans
 'version' => '1.2',
 'name' => 'Mentioner',
 'author' => 'clonemeagain@gmail.com',
 'description' => 'Notices @mentions and those names as collaborators.',
 'url' => 'https://github.com/clonemeagain/osticket-plugin-mentioner',
 'plugin' => 'class.MentionerPlugin.php:MentionerPlugin'
);
